package diaballik.model;

/**
 * Color of a player and theirs pawn
 * Yellow = player1
 * Green = player2 or IA
 */
public enum Color {
	Green,
	Yellow
}
