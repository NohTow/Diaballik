package diaballik.model;



public class Ball {
}
