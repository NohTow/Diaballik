package diaballik.model;


/**
 * Progressive level of an IA
 */
public class Progressive implements Strategy {
	@Override
	public void exec(final Game game) {
		//ToDo
	}
}
