package diaballik.resource;

public class NoGameCreatedException extends Exception {

	public NoGameCreatedException(final String message) {
		super(message);
	}
}
